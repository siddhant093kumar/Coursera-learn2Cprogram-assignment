#include<stdlib.h>
#include<stdio.h>
//Modelling of both saving (while working) and expenditure (while retired)
//Declare a struct _retire_info having months, contribution, rate_of_return
struct _retire_info{
  int months;
  double contribution;
  double rate_of_return;
};
typedef struct _retire_info retire_info;

void print_monthly_info(int months, double bal){
  printf("Age %3d month %2d you have $%.2f\n", months / 12, months%12, bal);
  return;
}

double bal_cal(double bal, retire_info retire_stats){
  bal += bal * retire_stats.rate_of_return;
  bal += retire_stats.contribution;
  return bal;
}
  
void retirement(int startAge,//in months
		double initial,//initial saving in dollars
		retire_info working,//info about working
		retire_info retired)//info about retired
{
  //set balance at intial start
  double bal = initial;
  int total_months = startAge-1;

  for(int i=0; i<working.months; i++){
    total_months += 1;
    print_monthly_info(total_months, bal);
    bal = bal_cal(bal, working);
  }
  for(int j =0; j<retired.months; j++){
    total_months += 1;
    print_monthly_info(total_months, bal);
    bal = bal_cal(bal, retired);
  }
  return;
}

int main(){
  retire_info working;
  working.months = 489;
  working.contribution = 1000;
  working.rate_of_return = 0.045/12.0;

  retire_info retired;
  retired.months = 384;
  retired.contribution = -4000;
  retired.rate_of_return = 0.01/12.0;

  retirement(327, 21345, working, retired);
  return 0;
}
